ÖDEV TAKİP — Android Studio kaynak projesi

Bu paket, mevcut HTML prototipini Android uygulaması olarak açan WebView tabanlı bir Android Studio projesidir. Native Android bildirim zamanlayıcısı dahildir.

Bildirim kuralı:
- Her ödev için teslim tarihinden 2 gün önce başlar.
- Her gün 13.00, 15.00, 17.00, 19.00 ve 21.00 saatleri için hatırlatma planlanır.
- Son teslim günü dahil hatırlatır; 21.00'den sonra hatırlatma yoktur.
- Ödev tamamlandı olarak kaydedilince uygulama zamanlanmış hatırlatmaları yeniden düzenler ve o ödev için gelecekteki hatırlatmaları iptal eder.
- Telefon yeniden başlatıldığında kayıtlı ödevler üzerinden plan tekrar kurulur.
- Android bildirim izni ilk açılışta istenir.

APK oluşturma:
1. Bilgisayara Android Studio (güncel sürüm) kur.
2. Bu ZIP'i çıkar, Android Studio'da OdevTakip klasörünü Open ile aç.
3. Gradle senkronizasyonu bitsin; SDK Platform 35 ve uyumlu Android Build Tools kurulmalı.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK, app/build/outputs/apk/debug/app-debug.apk altında oluşur.

Önemli:
- Bu ortamda Android SDK/Gradle olmadığı için imzalı/kurulabilir APK derlenemedi. ZIP Android Studio kaynak projesidir, APK değildir.
- Android 12+ sürümlerde sistem pil optimizasyonu/üretici kısıtları bildirimleri geciktirebilir. Zamanlama AlarmManager ile yapılır; sistemin kesin alarm erişimi vermediği cihazlarda saatler yaklaşık olabilir.
- Veriler cihazda saklanır, sunucuya gönderilmez.
- Öğrenci listesindeki adları, önceki konuşmadaki okunabilir listeye göre başlangıç verisi olarak içerir; isimleri kontrol et.
