package com.odevtakip.app;

import android.content.Context;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONObject;

public class ReminderBridge {
    private final Context context;
    public ReminderBridge(Context c) { context = c.getApplicationContext(); }
    @JavascriptInterface public void syncAssignments(String json) {
        try {
            context.getSharedPreferences("assignments_snapshot", Context.MODE_PRIVATE).edit().putString("json", json).apply();
            ReminderScheduler.sync(context, new JSONArray(json));
        } catch (Exception ignored) { }
    }
}
