package com.odevtakip.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class ReminderScheduler {
    private static final String PREF = "reminder_schedule";
    private static final int[] HOURS = {13, 15, 17, 19, 21};

    public static synchronized void sync(Context context, JSONArray assignments) {
        Context app = context.getApplicationContext();
        AlarmManager manager = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        SharedPreferences prefs = app.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        Set<String> old = prefs.getStringSet("request_codes", new HashSet<>());
        for (String value : new HashSet<>(old)) {
            try {
                int code = Integer.parseInt(value);
                Intent i = new Intent(app, ReminderReceiver.class);
                PendingIntent pi = PendingIntent.getBroadcast(app, code, i, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                if (pi != null) { manager.cancel(pi); pi.cancel(); }
            } catch (Exception ignored) {}
        }
        Set<String> codes = new HashSet<>();
        long now = System.currentTimeMillis();
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        for (int n=0; n<assignments.length(); n++) {
            JSONObject a = assignments.optJSONObject(n);
            if (a == null || a.optBoolean("completed", false)) continue;
            String id = a.optString("id", "");
            String due = a.optString("due", "");
            String subject = a.optString("subject", "Ödev");
            String description = a.optString("description", "Ödev teslimi");
            if (id.isEmpty() || due.length() != 10) continue;
            try {
                Calendar dueCal = Calendar.getInstance();
                dueCal.setTime(fmt.parse(due));
                dueCal.set(Calendar.HOUR_OF_DAY, 0); dueCal.set(Calendar.MINUTE,0); dueCal.set(Calendar.SECOND,0); dueCal.set(Calendar.MILLISECOND,0);
                Calendar start = (Calendar) dueCal.clone(); start.add(Calendar.DAY_OF_YEAR, -2);
                Calendar day = (Calendar) start.clone();
                while (!day.after(dueCal)) {
                    for (int hour : HOURS) {
                        Calendar fire = (Calendar) day.clone();
                        fire.set(Calendar.HOUR_OF_DAY, hour); fire.set(Calendar.MINUTE, 0); fire.set(Calendar.SECOND, 0); fire.set(Calendar.MILLISECOND, 0);
                        if (fire.getTimeInMillis() <= now) continue;
                        int requestCode = (id + "|" + fire.getTimeInMillis()).hashCode() & 0x7fffffff;
                        Intent intent = new Intent(app, ReminderReceiver.class);
                        intent.putExtra("assignmentId", id);
                        intent.putExtra("subject", subject);
                        intent.putExtra("description", description);
                        intent.putExtra("due", due);
                        intent.putExtra("requestCode", requestCode);
                        PendingIntent pi = PendingIntent.getBroadcast(app, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                        if (Build.VERSION.SDK_INT >= 23) manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fire.getTimeInMillis(), pi);
                        else manager.set(AlarmManager.RTC_WAKEUP, fire.getTimeInMillis(), pi);
                        codes.add(Integer.toString(requestCode));
                    }
                    day.add(Calendar.DAY_OF_YEAR, 1);
                }
            } catch (Exception ignored) {}
        }
        prefs.edit().putStringSet("request_codes", codes).apply();
    }
}
