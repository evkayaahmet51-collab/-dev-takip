package com.odevtakip.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String subject = intent.getStringExtra("subject");
        String description = intent.getStringExtra("description");
        String due = intent.getStringExtra("due");
        int id = intent.getIntExtra("requestCode", (int)System.currentTimeMillis());
        Intent launch = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        PendingIntent content = PendingIntent.getActivity(context, 1, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(context, "homework_reminders")
            : new Notification.Builder(context);
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Ödev hatırlatması")
            .setContentText((subject == null ? "Ödev" : subject) + ": " + (description == null ? "" : description))
            .setStyle(new Notification.BigTextStyle().bigText((subject == null ? "Ödev" : subject) + ": " + (description == null ? "" : description) + " · Son teslim: " + (due == null ? "" : due)))
            .setAutoCancel(true).setContentIntent(content);
        ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id, builder.build());
    }
}
