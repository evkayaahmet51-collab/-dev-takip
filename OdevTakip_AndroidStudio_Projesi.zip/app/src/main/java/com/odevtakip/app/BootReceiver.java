package com.odevtakip.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONArray;
import org.json.JSONObject;
import android.content.SharedPreferences;

/* Re-scheduling after reboot uses the last assignment snapshot saved by the bridge. */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        SharedPreferences p = context.getSharedPreferences("assignments_snapshot", Context.MODE_PRIVATE);
        String json = p.getString("json", "[]");
        try { ReminderScheduler.sync(context, new JSONArray(json)); } catch (Exception ignored) {}
    }
}
